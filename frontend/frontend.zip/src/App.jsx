import "./App.css";
import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";
import { useEffect, useState } from "react";
import Home from "./pages/Home";
import LegalDesk from "./pages/LegalDesk";
import Login from "./pages/Login";
import NotebookPage from "./pages/NotebookPage";
import FindLawyer from "./pages/FindLawyer";
import LawyerOnboard from "./pages/LawyerOnboard";
import LawyerRequests from "./pages/LawyerRequests";
import ChatView from "./pages/ChatView";
import MyClients from "./pages/MyClients";
import CompleteRegistration from './pages/CompleteRegistration';
import ProtectedRoute from "./components/ProtectedRoute";
import Sidebar from "./components/Sidebar";
import Header from "./components/Header";
import Footer from "./components/Footer";
import api from "./Axios/axios";
import useAuthStore from "./context/AuthContext";
import AuthCallback from "./pages/AuthCallback";
import { applyPalette, defaultPalette } from './utils/palette';
// import { LanguageProvider, useLanguage } from './context/LanguageContext';
// Google Translate widget loader
 


function App() {
  const token = useAuthStore((state) => state.token);
  const setUser = useAuthStore((state) => state.setUser);
  const [theme] = useState("light");

  useEffect(() => {
    const fetchProfile = async () => {
      try {
        if (!token) return;
        const resp = await api.get("/auth/me", {
          headers: { Authorization: `Bearer ${token}` },
        });
        setUser(resp.data.user);
      } catch (err) {
        console.error(err);
      }
    };
    fetchProfile();
  }, [token, setUser]);

  // Apply simple body-level theme class for light/dark toggling
  useEffect(() => {
    // initialize dynamic palette variables
    applyPalette(defaultPalette);
  }, [theme]);

  return (
    <Router>
      <div className="app-root min-h-screen">
      {/* LanguageProvider removed, not needed for Google Translate widget */}
  {/* header moved inside the right-side app column so it scrolls with main content */}

        

  <main className="w-full px-0 sm:px-0 lg:px-0 py-0 flex-1 overflow-auto">
          <Routes>
            <Route path="/login" element={<Login />} />
            <Route path="/auth/callback" element={<AuthCallback />} />

            {/* Protected area with sidebar + inner routes */}
            <Route
              path="/*"
              element={
                <div className="flex w-full h-full min-h-0">
                  <Sidebar />
                  <div className="flex-1 min-h-0 flex flex-col ml-72">
                            <Header />
                            <div className="flex-1 min-h-0 overflow-auto px-4 sm:px-6 lg:px-8 py-6">
                      <Routes>
                      <Route
                        path="/home"
                        element={
                          <ProtectedRoute>
                            <Home />
                          </ProtectedRoute>
                        }
                      />
                      <Route
                        path="/legal-desk"
                        element={
                          <ProtectedRoute>
                            <LegalDesk />
                          </ProtectedRoute>
                        }
                      />
                      <Route
                        path="/legal-desk/:id"
                        element={
                          <ProtectedRoute>
                            <NotebookPage />
                          </ProtectedRoute>
                        }
                      />
                      <Route
                        path="/find-lawyer"
                        element={
                          <ProtectedRoute>
                            <FindLawyer />
                          </ProtectedRoute>
                        }
                      />
                      <Route
                        path="/onboard-lawyer"
                        element={
                          <ProtectedRoute>
                            <LawyerOnboard />
                          </ProtectedRoute>
                        }
                      />
                      <Route
                        path="/complete-registration"
                        element={
                          <ProtectedRoute>
                            <CompleteRegistration />
                          </ProtectedRoute>
                        }
                      />
                      <Route
                        path="/lawyer/requests"
                        element={
                          <ProtectedRoute>
                            <LawyerRequests />
                          </ProtectedRoute>
                        }
                      />
                      <Route
                        path="/mylawyers"
                        element={
                          <ProtectedRoute>
                            <MyClients />
                          </ProtectedRoute>
                        }
                      />
                      <Route path="/chat/:id" element={<ProtectedRoute><ChatView /></ProtectedRoute>} />
                      <Route path="*" element={<Navigate to={'/home'} />} />
                      </Routes>
                    </div>
                  </div>
                </div>
              }
            />
          </Routes>
        </main>
        <Footer />
      </div>
    </Router>
  );
}

export default App;
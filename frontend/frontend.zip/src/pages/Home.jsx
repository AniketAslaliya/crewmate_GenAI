import React from "react";
import { motion } from "framer-motion";
import { useNavigate } from "react-router-dom";
import Button from '../components/ui/Button';

// Modern legal background with subtle pattern
const ModernBackground = () => (
  <div className="absolute inset-0 -z-10 bg-gradient-to-br from-[#e5e9f2] via-[#f8fafc] to-[#e0e7ef]">
    <div className="absolute inset-0 -z-10 opacity-10 pointer-events-none"
      style={{
        backgroundImage: `url("https://www.transparenttextures.com/patterns/pw-maze-white.png")`,
        backgroundRepeat: "repeat"
      }}
    />
    <div className="absolute inset-0 -z-10 bg-gradient-to-br from-transparent via-[#1e40af]/5 to-[#4b5563]/10" /> 
  </div>
);

const Home = () => {
  const navigate = useNavigate();

  return (
    <div className="relative w-full text-[var(--text)] font-sans bg-[var(--bg)] min-h-0 flex flex-col">
      <ModernBackground />

      <main className={`flex-1 min-h-0 overflow-auto px-6 py-10`}>
        <motion.div
          className="w-full mt-24 bg-card rounded-3xl border p-12 text-center backdrop-blur-sm"
          style={{ borderColor: 'var(--palette-3)' }}
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7 }}
        >
          <h2 className="text-5xl font-extrabold mb-4 text-[var(--color-primary)] font-serif">Welcome to Legal SahAI 👋</h2>
          <p className="text-gray-700 text-xl mb-3">
            Your secure, confidential, and expert legal workspace.
          </p>
          <p className="text-gray-600 text-lg mb-6">
            Effortlessly upload documents, organize your Legal Desks, and get AI-powered insights on any file.
          </p>
          <div className="mt-8">
            <Button variant="primary" onClick={() => navigate('/legal-desk')} className="px-8 py-3 font-semibold rounded-full">Go to Legal Desks</Button>
          </div>
        </motion.div>
      </main>
    </div>
  );
};

export default Home;